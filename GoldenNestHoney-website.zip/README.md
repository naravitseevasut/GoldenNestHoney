# Golden Nest Honey

โครงงานร้านน้ำผึ้ง 2 SKU (GNH-250 และ GNH-500) พร้อมตะกร้า ฟอร์มจัดส่ง และเมนูงานคลังใน Google Sheets

1. เปิด Google Sheet ใหม่ https://docs.google.com/spreadsheets/d/104vwG8wtHpvlxq_TG1wtselQyjg8ZubEbGNdLV0tZjI/edit → Extensions → Apps Script วางโค้ดจาก google-apps-script/Code.gs และบันทึก
2. ใน Apps Script เปิด Project Settings → Script Properties เพิ่ม ORDER_SECRET เป็นค่าสุ่มยาวอย่างน้อย 32 ตัวอักษร เก็บเป็นความลับ
3. Deploy → New deployment → Web app → Execute as Me → Who has access: Anyone → Deploy → คัดลอก URL ลงท้าย /exec ไม่ต้องเปิดแชร์ Sheet เป็นสาธารณะ
4. อัปโหลดไฟล์ทั้งหมดลง GitHub repository ใหม่ (ไฟล์ index.html อยู่ระดับราก และรักษาโฟลเดอร์ images, api, google-apps-script)
5. Vercel → New Project → Import repo → Framework Preset: Other → Environment Variables: GOOGLE_SCRIPT_URL = URL จากข้อ 3, ORDER_SECRET = ค่าเดียวกับข้อ 2 → Deploy
6. ทดสอบด้วยข้อมูลสมมติ เลือกสินค้า 2 SKU และสั่งซื้อ ตรวจสอบเลข Order ID ใน Orders เมื่อสำเร็จ
7. รีเฟรช Google Sheets เลือกแถวคำสั่งซื้อ แล้วเลือกเมนู Golden Nest → ใบหยิบสินค้า, ใบแพ็คสินค้า, ใบจ่าหน้าพัสดุ หรือสถานะถัดไป (Pending → Picked → Packed → Shipped) เติมที่อยู่และเบอร์โทรผู้ส่งก่อนจัดส่งจริง

ภาพสินค้าคือภาพวาด SVG จำลอง ราคาตัวอย่าง ไม่มีระบบชำระเงินจริง ไม่ควรเก็บข้อมูลส่วนตัวจริงจนกว่าจะตรวจสอบความปลอดภัยและความเป็นส่วนตัว รวมถึงระบบป้องกันคำสั่งซื้อปลอมและการใช้งานเกินกำหนด
